# SENTRIXI / AEGIS — SESSION HANDOVER DOCUMENT
## For continuation in a new Claude.ai session
**Generated:** April 24, 2026
**Author:** Oded Blatman (working with Claude)

---

## HOW TO USE THIS DOCUMENT

**Option A — Paste into a Claude Project as Knowledge:**
Create a new Project in Claude.ai, add this file as a knowledge document. Then upload all accompanying files (HTMLs, PNGs, strategy docs). Start chatting naturally — Claude will have full context.

**Option B — Paste into first message:**
Copy everything below the `---START CONTEXT---` line and paste it as your first message in a new chat. Then upload the files you need for the specific task you're working on.

---START CONTEXT---

## 1. WHO I AM

Oded Blatman. CIO & CISO at a NYDFS-regulated cryptocurrency custody firm (Fireblocks). 15+ years in regulated financial services security across 30+ global regions. Built a 20-agent AI behavioral detection and DFIR investigation platform (UBAD) used in active operations against organized cybercrime. Founder of Sentrixi.

---

## 2. WHAT SENTRIXI IS

Sentrixi is a pre-revenue cybersecurity startup. The core product is **AEGIS** — a database-layer behavioral security platform that detects insider threats, credential misuse, and data exfiltration at the query layer in real time (<20ms detection latency).

**Two-tier product architecture:**
- **AEGIS Shield (Tier 1):** Database-native security — real-time behavioral detection, anomaly scoring, query-level monitoring embedded directly into the database platform as an API-native sidecar. Zero production latency impact.
- **AEGIS Sentinel (Tier 2):** Full enterprise SIEM/security data lake — ingests all security logs (EDR, Cloud, Firewall, Identity) into the database, transforms it into a real-time autonomous SOC with 30+ specialist AI agents.

**Core thesis:** "The database layer is the last unprotected frontier in the enterprise security stack." CrowdStrike covers endpoints, Wiz covers cloud, Palo Alto covers network — nobody does behavioral detection at the data layer.

**GTM model:** OEM-first through database vendors (primarily SingleStore), creating new revenue streams for the vendor while embedding security as a platform capability. Think: "TLS became native to web servers — AEGIS becomes native to the database."

**Key differentiator vs Databricks Lakewatch:** Lakewatch is an open agentic SIEM (log aggregation + detection). AEGIS starts at the database itself (Phase 1: protect the database natively) then expands outward (Phase 2: become the SIEM). This inside-out approach is architecturally stronger.

---

## 3. SINGLESTORE CONTEXT

SingleStore is a PE-backed (Vector Capital) real-time database company. Key stakeholders:
- **Raj Verma** — CEO, framed the combined CIO/CISO/AI role as part of a "tech trio"
- **Elmer Lai** — CFO, Oded's long-standing friend, primary negotiating counterpart
- **Kiran & Amish** — Vector Capital decision-makers

Oded is simultaneously negotiating a CIO/CISO/Head of AI executive role at SingleStore AND positioning Sentrixi as a strategic $1M investment/JV opportunity for SingleStore. The AEGIS pitch to SingleStore frames security as a consumption multiplier (>3x data volume) and IPO moat differentiator.

Key documents in the project knowledge (not included in this handover but referenced):
- Strategic Brief: Project AEGIS (Sentrixi)
- Sentrixi x SingleStore: Strategic Partnership & Investment Proposal
- Strategic Investment Roadmap: Sentrixi & SingleStore $1M Partnership
- The AEGIS Pitch: From CIO to Strategic Partner (call script)
- Sentrixi Board Presentation Deck (Draft)
- Strategic GTM & Market Dominance: The AEGIS Shield (CEO & Board Brief)
- Sentrixi-SingleStore JV: Economic & Financial Model (CFO Brief)

---

## 4. WHAT WE BUILT IN THIS SESSION (April 24, 2026)

### 4A. Sentrixi.com Website Analysis & Redesign

**Starting point:** Current sentrixi.com was reviewed through a CISO/SOC manager lens. Key feedback:
- Strong thesis ("database layer is unprotected") but trust gap between compelling thesis and proof
- "Sub-20ms detection" needs architectural proof, not just a stat
- No customer evidence, no logos, no case study
- "Combat-proven" language needs backing
- No pricing, no POC path — "Schedule a Briefing" as only CTA is friction
- Solo founder risk for enterprise procurement

**Databricks Lakewatch comparison analysis:** We analyzed https://www.databricks.com/blog/databricks-announces-lakewatch-new-open-agentic-siem and identified 5 structural reasons it's more compelling:
1. **Threat-first narrative** — Lakewatch leads with the threat landscape, not the product
2. **Third-party proof at every layer** — Adobe, Dropbox, Zscaler, Deloitte quotes; 16+ partners
3. **Quantified pain** — "80% cost reduction," "petabytes of retention," specific economics
4. **Self-evident architecture** — "storage decoupled from compute" is a first-principles insight
5. **Ecosystem signals inevitability** — OCSF open formats, partner logos everywhere

### 4B. Website V2 (sentrixi-v2.html) — REJECTED
A text-heavy redesign applying Databricks lessons. Oded's feedback: "fire the UI/UX expert. It looks bad. Too much text, looks PDF, not advanced innovative AI website. No simple infographics/animations."

### 4C. Website V3 (sentrixi-v3.html) — CURRENT APPROVED DIRECTION
Complete rebuild: visual-first, animated, minimal text, modern AI startup aesthetic. Features:
- Animated orbs + grid hero with scroll-reveal animations
- Visual stack infographic showing the security gap (green "COVERED" badges cascading, then red "EXPOSED" for database layer)
- Animated counter stats on scroll (68% breaches, 277 days, $4.9M cost, <20ms detection)
- Architecture flow diagram with animated pulse particles
- DFIR scenario as visual timeline (not paragraphs)
- Red/green side-by-side outcome comparison
- Vendor economics cards, compliance chips
- "Request Sandbox Access" as second CTA (not just "briefing")
- Honest advisory board placeholder

**Design principles established:**
- Visual-first, not text-first
- Infographics > paragraphs
- Animations that explain, not decorate
- Dark theme, modern AI startup energy
- Max 1-2 sentences per section, let the visual do the work
- Two CTAs: "Request Technical Briefing" + "Request Sandbox Access"

### 4D. AEGIS Dashboard Screenshots — Production Dark Theme
Oded uploaded 7 screenshots of AEGIS platform screens (white/light background, document-style) and asked for them to be rebuilt as dark production-grade dashboards suitable for the marketing website. "Like a real system but with the data in the pictures."

**6 dashboards built and rendered as PNGs:**

| # | File | What it shows |
|---|------|---------------|
| 01 | `01_soc_dashboard.html` / `AEGIS_01_SOC_Executive_Dashboard.png` | KPI strip (12,847 evt/s, 47ms latency, 7 active threats, 30/30 agents, 340ms MTTR), agent fleet bars with gradient fills, stacked bar chart, threat queue table, data source health, AI engine metrics |
| 02 | `02_kill_chain.html` / `AEGIS_02_Kill_Chain_Process_Compromise.png` | Incident header (0.96 confidence, 23ms detection), full MITRE ATT&CK v14 kill chain timeline (8 stages: Initial Access → Exfiltration/Blocked), process tree with syntax highlighting, Claude Opus forensic analysis, threat actor match bars (Scattered Spider 84%, Volt Typhoon 67%, Lazarus 42%, APT41 31%) |
| 03 | `03_guardian_response.html` / `AEGIS_03_Guardian_Response_Console.png` | Armed/selective mode, threat context (DVWS-PC01, PID 4712, 0.96 confidence), 5 response action cards with toggle switches and progress bars (quarantine executed 1.8s, process kill executed 2.1s, session termination ready, user disable pending human approval, API revoke ready), audit log, bottom stats (23ms detection, 1.8s containment) |
| 04 | `04_agent_fleet.html` / `AEGIS_04_Agent_Fleet_30_Agents.png` | 6 domain groups (Identity 5 agents/3,241 evt/min, Endpoint 6/5,102, Network 4/2,890, Cloud 5/1,847, LOTL 4/967, Application 6/4,210), per-agent rows with health indicators, AI engine throughput (ML brain 12,847 evt/s 4.2ms avg, LLM brain Haiku 180ms/Sonnet 2.4s/Opus 8.1s, fleet 30 agents 29 healthy 1 elevated 18.2M events/24h) |
| 05 | `05_forensic_report.html` / `AEGIS_05_Forensic_Report.png` | Confidential banner, report header (AEGIS-FR-2026-0422-0031), 4 KPI cards (DVWS-PC01, Critical 0.96, 23ms detection, 1.8s containment), executive summary, evidence chain table (8 events with MITRE links), response actions table (3 actions), SHA-256 evidence chain integrity hash, export buttons (PDF, STIX 2.1, Push to Sentinel) |
| 06 | `06_lotl_simulation.html` / `AEGIS_06_LOTL_Attack_Simulation.png` | Sandbox/Simulation mode, MITRE progress bar (Delivery→Execution→Persistence→Evasion→Credential access→C2→Lateral→Contained), dark terminal with syntax-highlighted attack replay (Scattered Spider LOLBin chain), playback controls (0.5x/1x/2x), 4 agent detection cards, bottom stats (6 agents triggered, 23ms first detection) |

**All dashboards use the same design system:**
- Background: #0a0c10
- Cards: #111827 with #1e293b borders
- Fonts: Inter (UI) + JetBrains Mono (data/code)
- Color coding: Red (#ef4444) for critical/threats, Green (#22c55e) for healthy/success, Amber (#f59e0b) for warnings/pending, Blue (#3b82f6) for primary/info, Purple (#a78bfa) for cloud metrics
- Consistent component patterns: KPI strips, card headers, severity badges, agent tags, progress bars, audit logs

**The scenario across all dashboards is the same attack chain:**
A Scattered Spider LOLBin attack on DVWS-PC01: spearphishing → EXCEL.EXE → cmd.exe → mshta.exe → powershell.exe → certutil.exe → svchost.exe process hollowing → LSASS credential dump → DNS C2 beaconing → lateral movement attempt to DVWS-DC02 → Guardian autonomous containment in 1.8 seconds.

---

## 5. WHAT STILL NEEDS TO BE DONE

### Website (sentrixi-v3.html):
- [ ] Integrate the dark dashboard PNGs into the website as product showcase section (image carousel or scroll-reveal gallery)
- [ ] Add a "Live Demo" or "Product Tour" section using the dashboards
- [ ] Refine responsive/mobile layout
- [ ] Add real GA4 tracking (measurement ID needed)
- [ ] Deploy to sentrixi.com via Vercel (Next.js setup exists — see DEPLOY.md in project files)
- [ ] Consider separate landing pages: one for OEM/vendor partnerships, one for enterprise buyers
- [ ] Verify/update the threat statistics (68%, 277 days, $4.9M) with actual 2025/2026 report citations

### Dashboards:
- [ ] Re-render PNGs at 2x resolution (retina) for crisp website display
- [ ] Consider adding subtle CSS animations to the HTML versions for an interactive demo mode
- [ ] Create a 7th dashboard: the "before/after" comparison (traditional SOC vs AEGIS detection timeline)

### Strategy:
- [ ] Finalize SingleStore pitch deck incorporating dashboard visuals
- [ ] Build the interactive demo/sandbox that the "Request Sandbox Access" CTA promises
- [ ] Recruit advisory board members to fill the placeholder section

---

## 6. FILE MANIFEST

All files in the handover bundle:

### Handover
- `SENTRIXI_HANDOVER.md` — this document

### Website Versions
- `sentrixi-v2.html` — V2 (rejected, text-heavy)
- `sentrixi-v3.html` — V3 (approved direction, visual-first)

### Dashboard HTML Sources (dark production theme)
- `01_soc_dashboard.html` — SOC Executive Dashboard
- `02_kill_chain.html` — Kill Chain Analysis
- `03_guardian_response.html` — Guardian Response Console
- `04_agent_fleet.html` — Agent Fleet (30 agents)
- `05_forensic_report.html` — Forensic Investigation Report
- `06_lotl_simulation.html` — LOTL Attack Simulation

### Dashboard PNGs (rendered at 1440px)
- `AEGIS_01_SOC_Executive_Dashboard.png`
- `AEGIS_02_Kill_Chain_Process_Compromise.png`
- `AEGIS_03_Guardian_Response_Console.png`
- `AEGIS_04_Agent_Fleet_30_Agents.png`
- `AEGIS_05_Forensic_Report.png`
- `AEGIS_06_LOTL_Attack_Simulation.png`

---

## 7. DESIGN & TONE PREFERENCES

- **Visual-first:** Infographics and animations over text. If it can be shown, don't write it.
- **Dark theme:** All production visuals use dark backgrounds (#0a0c10 range)
- **Modern AI startup aesthetic:** Think CrowdStrike Falcon meets Datadog, not corporate PDF
- **Minimal text per section:** 1-2 sentences max, let visuals carry the message
- **Collaborative tone in all communications:** Warm, non-adversarial, referencing shared history
- **CISO credibility:** Every claim needs architectural proof or a sanitized case study
- **Two audience paths:** Database vendors (revenue economics) and enterprises (threat scenarios)

---

## 8. KEY INSIGHTS TO PRESERVE

1. **The Databricks Lakewatch lesson:** Lead with threat narrative, not product. Architecture > features. Third-party proof > self-claims. Ecosystem signals inevitability.

2. **AEGIS vs Lakewatch positioning:** Lakewatch is outside-in (aggregate logs → detect). AEGIS is inside-out (protect the database first → expand to SIEM). Inside-out is architecturally stronger because it starts where the data lives.

3. **The website must make readers feel smart, scared, and hopeful — in that order.** Smart (understand the gap), scared (the gap is real and urgent), hopeful (AEGIS closes it with sound architecture and proof).

4. **"Request Sandbox Access" as a CTA is critical.** SOC managers want to test, not listen to pitches. This one button changes conversion psychology.

5. **The advisory board placeholder (honest, not empty) builds more trust** than pretending to have a team. Signal self-awareness and ambition.

---END CONTEXT---

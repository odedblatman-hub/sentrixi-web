import Head from "next/head";
import Script from "next/script";

const GA4_ID = "G-XXXXXXXXXX"; // ← Replace with your real Measurement ID

export default function App({ Component, pageProps }) {
  return (
    <>
      <Head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Sentrixi — Threats move fast. Sentrixi moves faster.</title>
        <meta name="description" content="Enterprise security operating at machine speed. 30 AI agents. 120+ capabilities. Autonomous detection, instant containment, always current." />
        <meta name="theme-color" content="#0F172A" />

        {/* Open Graph */}
        <meta property="og:type"        content="website" />
        <meta property="og:url"         content="https://sentrixi.com/" />
        <meta property="og:title"       content="Sentrixi — Threats move fast. Sentrixi moves faster." />
        <meta property="og:description" content="30 AI agents. 120+ capabilities. Autonomous SOC platform in production." />
        <meta property="og:image"       content="https://sentrixi.com/og-image.png" />

        {/* Twitter */}
        <meta name="twitter:card"        content="summary_large_image" />
        <meta name="twitter:title"       content="Sentrixi — Machine-speed security" />
        <meta name="twitter:description" content="30 AI agents. Autonomous detection. Always current." />
        <meta name="twitter:image"       content="https://sentrixi.com/og-image.png" />

        {/* Favicon */}
        <link rel="icon"             href="/favicon.svg" type="image/svg+xml" />
        <link rel="icon"             href="/favicon.ico" sizes="any" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />

        {/* Canonical */}
        <link rel="canonical" href="https://sentrixi.com/" />
      </Head>

      {/* GA4 */}
      <Script
        src={`https://www.googletagmanager.com/gtag/js?id=${GA4_ID}`}
        strategy="afterInteractive"
      />
      <Script id="ga4-init" strategy="afterInteractive">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', '${GA4_ID}', {
            page_path: window.location.pathname,
            send_page_view: true,
          });
        `}
      </Script>

      <Component {...pageProps} />
    </>
  );
}

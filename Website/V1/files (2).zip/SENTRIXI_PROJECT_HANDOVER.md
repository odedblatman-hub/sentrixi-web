# SENTRIXI PROJECT HANDOVER
## Complete Status Document — April 19, 2026
### For: All Claude sessions working on this project

---

## 1. COMPANY OVERVIEW

**Company:** Sentrixi (formerly Guardrix)
**Domain:** sentrixi.com
**Founder:** Oded Blatman (CIO & CISO at Fireblocks)
**Stage:** Pre-launch / early GTM
**Product:** AEGIS — Autonomous Enterprise Guardian Intelligence System

**One-line pitch:** The first AI-native Autonomous SOC platform purpose-built for the real-time data era. 30 specialist AI agents (growing to 60+), dual-brain ML+LLM architecture, self-learning flywheel, Forensic Genie — operating at machine speed.

---

## 2. LOCKED BRAND DECISIONS

### Company name
- **Public brand:** Sentrixi
- **Product name:** AEGIS (Autonomous Enterprise Guardian Intelligence System)
- **Domain:** sentrixi.com
- **Do NOT mention:** Fireblocks (IP sensitivity) — reference as "Tier-1 regulated fintech" or "production at a Tier-1 regulated fintech — 18 months, zero critical incidents missed"

### Logo — "The Orbital Sentinel"
- 330° orbital ring (open at 3 o'clock — implies motion, not a static shield)
- Two satellite nodes: upper-right (cx=49, cy=15) and lower-left (cx=15, cy=49)
- Dual-circle hub: navy outer circle + teal inner dot
- Wordmark: "Sentri" in DM Sans 500 + "xi" in Instrument Serif italic, teal
- SVG viewBox="0 0 64 64"

### Color palette (locked)
```
Teal primary:   #0D9488
Teal dark:      #0F766E
Teal light:     #CCFBF1
Teal XL:        #F0FDFA
Navy:           #0F172A
Navy mid:       #1E293B
Ivory bg:       #FAFAF7
Border:         #E2E8F0
Muted text:     #64748B
Red:            #DC2626
Amber:          #D97706
Success:        #059669
Purple:         #7C3AED
```

### Typography (locked)
- Display/headlines: Instrument Serif (italic for accent words)
- Body/UI: DM Sans 300/400/500
- Code/mono: DM Mono
- Google Fonts import URL is in the CSS

### Tagline (locked)
**"Autonomous. Expert. Always Ahead."**

### Hero headline — A/B TEST RUNNING
- **Variant A:** "Threats move fast. *Sentrixi moves faster.*"
- **Variant B:** "Your Entire Security Team. In a *Single Platform.* Always On."
- A/B split is random (50/50), stored in sessionStorage key `sx-hl`
- GA4 event: `headline_variant_shown` with `{variant: "A"|"B"}`
- DO NOT resolve the A/B test — let analytics determine winner

---

## 3. WEBSITE — CURRENT STATUS

### Latest file: `sentrixi_v4.jsx`
This is the MASTER FILE. Always use v4 as the base for any future edits.

**File stats:** 1,402 lines · 89.2KB · Single React component · Zero brace errors

### Pages built
1. **Home** — Full homepage with all sections (see section order below)
2. **Platform** — Architecture, named threat actors, spec cards, Forensic Genie spotlight
3. **About** — Founder bio (Oded Blatman), career timeline, mission statement
4. **Contact** — Full form (name, email, company, role, message) → success state

### Homepage section order (v4)
1. Hero (A/B headline, live badge, zero-incident proof box, email capture, ROI Calculator)
2. Stats bar (navy background: 30 agents, 120+ capabilities, <500ms, 197→0 dwell, NYDFS)
3. **For Platform Teams** (prominent — investor story, SingleStore framing without naming them)
4. Act 2 — The Broken Model (197 days, $4M, <5% alerts, 8% FP rate)
5. Agent Team grid (8 named agents: Sentinel, Cognito, Nexus, Lex, Argus, Atlas, Nimbus, Oracle)
6. Forensic Genie interactive demo (animated — click Run Analysis)
7. Five Unfair Advantages (dark navy section)
8. Before/After comparison (real CMO numbers)
9. Risk Dial (canvas-based, animated needle, before/after toggle)
10. Social proof (CISO quote)
11. Platform/OEM section (second occurrence, for deep scrollers)
12. Features grid (6 cards)
13. CTA (email capture)

---

## 4. INTERACTIVE COMPONENTS (all built in v4)

### ROI Calculator (`<ROICalculator/>`)
- Located: hero column, below email capture
- Three tabs: CISO / CEO+Board / CFO
- CISO: slider (2–50 analysts) → hours saved live calculation
- CFO: slider ($500K–$10M SOC cost) → annual savings, 3-year ROI, payback period
- CEO: static proof cards (0 incidents, SOC 2, 99.97% SLA)
- GA4 events fire on tab switch

### Risk Dial (`<RiskDial/>`)
- Canvas-based semicircle gauge with 5 colored zones
- Starts at score 78 (High risk)
- "Enable Sentrixi" button → needle animates to 12 (Minimal)
- 4 metric cards flip red→green simultaneously (dwell time, coverage, MTTR, FP rate)
- Uses requestAnimationFrame for smooth needle animation
- GA4 event: `risk_dial_toggle` with `{state: "on"|"off"}`

### Forensic Genie Demo (`<ForensicGenieDemo/>`)
- Click "▶ Run analysis" to start
- User profile: Sarah Chen (Senior Lead, Engineering)
- 6 animated steps with spinning loader → ✓ on completion
- Risk badge animates HIGH → CRITICAL during analysis
- DFIR narrative typewriter effect (character-by-character, ~22ms per 4 chars)
- Court-admissible PDF row appears on completion
- "↺ Reset demo" button resets all state
- GA4 event: `genie_demo_started`

### Incident Timeline (`<IncidentTimeline/>`)
- 4 steps: threat detected → Sentinel → Nexus → resolved
- Auto-plays, loops every ~4 seconds
- Resolution bar appears with 487ms / 0 analysts / 0 bytes stats
- Enhanced sub-text shows cross-source correlation detail

### Constellation Canvas (`<ConstellationCanvas/>`)
- 16 named agent nodes orbiting central SENTRIXI hub
- Random agent triggers "alert" state (red) every 5.2 seconds
- Auto-resolves after 2.4 seconds
- Alert fires `onAlert(agentName)` → updates ticker bar below canvas

### Video Player (`<VideoPlayer/>`)
- Chaptered progress player (placeholder for real video)
- 4 chapters: Problem / Agent fleet / Live incident / Next step
- Play/pause toggle, progress bar, chapter highlighting
- Designed to accept real HeyGen video embed as iframe replacement

### A/B Headline Hook (`useHeadlineVariant()`)
- Random assignment on first load, persists in sessionStorage
- Returns "A" or "B"
- Fires GA4 event on assignment

---

## 5. ANALYTICS — GA4 SETUP

### Configuration
- GA4_ID placeholder: `G-XXXXXXXXXX` (in both `_app.jsx` and `SentrixiApp.jsx`)
- Replace with real Measurement ID from analytics.google.com
- Script auto-injects via Next.js `<Script strategy="afterInteractive">`

### Events tracked
| Event name | Trigger | Params |
|---|---|---|
| `headline_variant_shown` | Page load | `{variant: "A"\|"B"}` |
| `email_capture` | Email form submit | `{email, location, label}` |
| `demo_request` | Contact form submit | `{role, company}` |
| `risk_dial_toggle` | Risk dial button | `{state: "on"\|"off"}` |
| `genie_demo_started` | Forensic Genie button | — |
| `page_view` | Nav click | `{page: "home"\|"product"\|"about"\|"contact"}` |

### Email capture — NOT YET WIRED TO BACKEND
Currently fires GA4 only. To actually store emails, choose one:
- **Resend (easiest):** Create `pages/api/subscribe.js`, send email notification per capture
- **Mailchimp:** Use List API with your List ID + API Key
- Both options are documented in `DEPLOY.md`

---

## 6. CMO MESSAGING — LOCKED DECISIONS

### Positioning
- **Primary:** Autonomous SOC replacement (CISO/Security Director buyers)
- **Secondary:** Security as a Feature / OEM platform play (CTO/CPO at data infrastructure companies)

### Four-act narrative (homepage structure)
1. **Act 1 (Problem):** Attackers run at machine speed. Your SOC runs on human time.
2. **Act 2 (Failed Fix):** You hired analysts, bought tools, wrote playbooks — 197 days dwell time still.
3. **Act 3 (Breakthrough):** AEGIS — 30 specialist AI agents, dual-brain, self-learning, Forensic Genie.
4. **Act 4 (New World):** Fortune 100 security posture. Machine speed. No burnout.

### Key stats (use these, not alternatives)
- 197 days: avg attacker dwell time (industry stat)
- <500ms: Sentrixi detection + response (codebase verified)
- <60 seconds: Sentrixi dwell time elimination (CMO brief)
- 8%: industry false positive rate
- <5%: alerts investigated in traditional SOC
- $1.5M–$4M: annual enterprise SOC cost range
- $890K: Sentrixi annual platform cost (avg)
- 73%: SOC cost reduction
- 18 months: production runtime at Tier-1 fintech
- 0: critical incidents missed in production
- 30: current specialist AI agents (production-verified)
- 60+: roadmap agent count (say "growing to 60+ specialists")
- 120+: capabilities

### Five unfair advantages (always list in this order)
1. Dual-brain architecture (ML fast path + LLM deep path)
2. 30+ specialist agents (growing to 60+)
3. Self-learning flywheel (weekly AutoML retraining)
4. Forensic Genie (Claude-powered DFIR, runs daily/3hr)
5. Built to embed (white-label, OEM, API-first)

### Named threat actors — on Product page
Always refer to by name — no other competitor has named-actor detection:
- **Lazarus Group** (DPRK, crypto theft, SWIFT targeting)
- **Volt Typhoon** (PRC, LOTL, critical infrastructure)
- **Scattered Spider** (social engineering, MFA fatigue, Okta compromise)
- **APT41** (PRC, dual espionage + crime, supply chain)

### Platform/OEM copy (SingleStore framing — never name them)
Key phrase: *"Real-time data platforms, cloud infrastructure vendors, and SaaS companies are losing regulated enterprise deals — banks, fintechs, healthcare systems — because they can't prove security operations at the level buyers require."*

### What NOT to say
- ❌ "Prevent" risks (AEGIS detects, responds, contains — it doesn't prevent)
- ❌ "Fireblocks" (IP sensitivity — say "Tier-1 regulated fintech")
- ❌ "30 AI agents" without context (add "specialist" or "growing to 60+")
- ❌ Any fear-based negative framing in hero (use confidence/speed framing)

---

## 7. PRODUCT TECHNICAL FACTS (verified from codebase)

### Agent count
- **Production today:** 30 agents (25 general detection + 5 insider threat fleet)
- **Roadmap:** 60+ specialists
- Use: "30 specialist AI agents today, growing to 60+"

### Architecture
- Fast path: ML heuristics, <500ms, threshold 0.65 to trigger LLM
- Deep path: Claude Haiku (default) → Opus (when ML score ≥0.85)
- LLM routing: Gemini Flash (fast surfaces) / Claude Sonnet (analysis) / Claude Opus (Genie + deep)

### Forensic Genie (production)
- Runs daily at 05:00 UTC for ALL high/critical risk users
- Runs every 3 hours for critical-risk entities
- OSINT sources: VirusTotal, Shodan, AbuseIPDB, GreyNoise, Pulsedive, WHOIS, HIBP, URLScan, CrowdStrike Intel, on-chain analytics, web OSINT (11 total)
- Output: DFIR narrative + forensic PDF (court-admissible)

### Kill Chain Engine
- Maintains live hypothesis graphs per workspace
- Updated within 60 seconds of new events
- Pre-built playbooks: Lazarus Group, Scattered Spider, Volt Typhoon, APT41
- P0 alert at confidence ≥ 0.85

### Guardian Response Engine
- 5 individually-armable response actions
- Always starts in detection-only mode (fully disarmed)
- Safety-critical actions (freeze transactions, disable sessions) always require human approval
- Full audit trail on every action

### Self-Learning Pipeline
- Weekly AutoML retraining with SMOTE class-imbalance correction
- Federated learning with differential privacy (ε=1.0)
- Shadow deployment for safe model promotion
- Online learning from analyst feedback (TP/FP/missed)

### SIEM Integration
- Bidirectional pipeline with Microsoft Sentinel
- Daily scanner + hourly sync
- Natural language → KQL via Claude Haiku
- Tables: `UbaAlerts_CL`, `InsiderThreat_CL`

### Compliance (production-verified)
- NYDFS 23 NYCRR 500 ✓
- MITRE ATT&CK (auto-mapped on every finding) ✓
- SOC 2 (continuously audit-ready) ✓
- ISO 27001 ✓
- NIST CSF ✓

---

## 8. DEPLOYMENT SETUP

### File structure for Next.js
```
sentrixi-site/
├── components/
│   └── SentrixiApp.jsx    ← sentrixi_v4.jsx renamed
├── pages/
│   ├── _app.jsx           ← meta tags, GA4 injection
│   └── index.jsx          ← exports SentrixiApp
├── public/
│   ├── favicon.svg        ← Orbital Sentinel mark on navy bg
│   └── robots.txt
├── next.config.js         ← security headers, CSP
├── package.json           ← Next.js 14.2.5, React 18
└── vercel.json            ← regions cdg1 + iad1, cache headers
```

### Deploy steps (fast path)
1. `npm install` in project root
2. Replace `G-XXXXXXXXXX` in `_app.jsx` AND `SentrixiApp.jsx` with GA4 ID
3. `npm run dev` — verify locally at localhost:3000
4. Push to GitHub → Vercel auto-detects Next.js → deploys
5. Add domain in Vercel → DNS A record: `76.76.21.21`
6. SSL auto-provisioned

### Deploy steps (Cloudflare alternative)
- Same build config, add `output: 'standalone'` to next.config.js
- Custom domain auto-configures if domain is already on Cloudflare

### Full deploy guide: `DEPLOY.md` (separate file in project)

---

## 9. OUTSTANDING TASKS / WHAT'S NOT DONE YET

### Priority 1 — Needs action before launch
- [ ] **Get GA4 Measurement ID** — replace `G-XXXXXXXXXX` in 2 files
- [ ] **Wire email capture to backend** — Resend or Mailchimp (15 min, documented in DEPLOY.md)
- [ ] **Register sentrixi.com** — domain not yet confirmed registered
- [ ] **HeyGen video** — video slot is a placeholder player; needs real AI narrator video

### Priority 2 — Post-launch
- [ ] **OG image** — `public/og-image.png` referenced in `_app.jsx` but not created
- [ ] **Sitemap** — `sitemap.xml` referenced in robots.txt, not generated
- [ ] **Google Search Console** — submit sitemap after launch
- [ ] **Analytics review** — check A/B headline performance after 200+ visits
- [ ] **Email backend upgrade** — move from Resend notification to proper CRM (HubSpot/Mailchimp)
- [ ] **Calendly integration** — contact form currently shows success state; connect to real calendar

### Priority 3 — Nice to have
- [ ] **Apple touch icon** — `public/apple-touch-icon.png` referenced, not created
- [ ] **Favicon.ico** — SVG favicon works in modern browsers; .ico for IE/legacy
- [ ] **Mobile nav** — nav links hidden on mobile; hamburger menu not built
- [ ] **Founder photo** — About page has emoji placeholder; replace with real photo

---

## 10. SINGLESTORE / INVESTOR CONTEXT

### Why SingleStore matters
- They are the primary target partner/investor
- AEGIS JV Proposal has been prepared (see `AEGIS_JV_Proposal.docx` in project)
- Proposed JV: 50/50 equity split, SingleStore × Fireblocks
- SingleStore pain points addressed by Sentrixi:
  - Goldman Sachs concentration risk ($5.7M ARR, -3% GM) — AEGIS creates diversification
  - CISO search listed as board priority (Slide 34 of their MOR)
  - ClickHouse competitive threat — AEGIS creates a moat ClickHouse cannot replicate
  - "Readiness for agentic AI" is a stated Value Creation Priority

### JV financial model
- Year 1: $2.4M ARR (15 existing upsell + 5 new logo @ $120K ACV)
- Year 2: $7.5M ARR
- Year 3: $15.75M ARR (60 customers @ $175K ACV)
- Investment: $2.75M Year 1, split 50/50 = $1.375M per parent
- Gross margin: 75% → 82%
- 11.5× return on invested capital at Year 3

### Next steps with SingleStore (per JV proposal)
- Executive alignment call: Week of April 21, 2026 (Oded + Elmer/Andy)
- Technical deep-dive: Week of April 28, 2026
- Commercial term sheet: May 15, 2026
- Board approval: June 2026
- JV entity formation: July 2026
- Phase 1 kickoff: August 2026

### Key contact
- **Elmer Lai** — primary contact at SingleStore (email drafted, 3 versions)

---

## 11. ALL OUTPUT FILES (chronological)

| File | Description | Status |
|---|---|---|
| `email_to_elmer_lai.md` | 3 email versions to SingleStore contact | ✅ Done |
| `AEGIS_JV_Proposal.docx` | Full board-level JV proposal | ✅ Done |
| `singlestore_cio_analysis.tsx` | SingleStore CIO role analysis | ✅ Done |
| `full_singlestore_report.html` | Full due diligence report | ✅ Done |
| `comp_risk_verification.html` | Compensation risk analysis | ✅ Done |
| `sentrixi_full.jsx` | Website v1 (original build) | ⚠️ Superseded |
| `sentrixi_v2.jsx` | Website v2 (CMO updates) | ⚠️ Superseded |
| `sentrixi_v3.jsx` | Website v3 (interactive components) | ⚠️ Superseded |
| `sentrixi_v4.jsx` | **Website v4 — MASTER FILE** | ✅ Current |
| `package.json` | Next.js project config | ✅ Done |
| `next.config.js` | Security headers, CSP | ✅ Done |
| `vercel.json` | Vercel deployment config | ✅ Done |
| `_app.jsx` | Next.js app wrapper, GA4, meta tags | ✅ Done |
| `index.jsx` | Page entry point | ✅ Done |
| `favicon.svg` | Orbital Sentinel favicon | ✅ Done |
| `DEPLOY.md` | Full deployment guide (Vercel + Cloudflare) | ✅ Done |

**ALWAYS use `sentrixi_v4.jsx` as the base. Never edit v1/v2/v3.**

---

## 12. FOUNDER DETAILS (for About page / contact)

**Name:** Oded Blatman
**Role:** Founder & CEO, Sentrixi
**Background:** 30 years security infrastructure, CIO & CISO at Fireblocks (2019–2026)
**Phone:** +972-52-299-2014
**Email:** oded@sentrixi.com (or oded@guardrix.com in older docs)
**LinkedIn:** linkedin.com/in/oded-blatman

---

*Last updated: April 19, 2026*
*Updated by: Claude (Anthropic) working session*
*Next session: load this document first, then load `sentrixi_v4.jsx` for any website edits*

export { default } from "../components/SentrixiApp";
